# Roadmap — Plasma AI Usage Monitor

> **Current version:** v5.4.1 (Link)
> **Last updated:** 2026-04-22
> **Direction:** Keep the widget desktop-native and local-first. Prefer export, notifications, and loopback integrations over backend/server expansion.

## Analyst's Note on Feasibility

The earlier Horizon/Nexus direction pushed toward web dashboards, PostgreSQL, and multi-user infrastructure. That is not a good fit for a KDE Plasma widget. The project now stays focused on:

- local monitoring and distribution
- browser sync where technically realistic on Linux
- local integrations such as Prometheus, webhooks, and scheduled exports

Chrome/Chromium cookie decryption and AWS Bedrock support remain in scope, but both are explicitly higher-risk Linux desktop integrations.

## Version Summary

| Version | Codename | Theme | Status |
| ------- | -------- | ----- | ------ |
| v5.2.0 | **Lighthouse** | Operator clarity and runtime consolidation | Released |
| v5.3.0 | **Vanguard** | Distribution and local tools | Released |
| v5.4.1 | **Link** | Advanced sync and enterprise API | Released |
| v6.0.0 | **Nexus (Light)** | Integration and standard export | Planned |

## v5.4.1 — "Link"

**Goal:** extend browser sync beyond Firefox on Linux and add AWS Bedrock without turning the widget into a cloud control plane. Includes 5.4.1 hotfix for COPR test environments.

| Feature | Description | Technical Risk |
| ------- | ----------- | -------------- |
| **Chrome/Chromium sync** | Linux-only profile discovery plus cookie reads/decryption when safe-storage secrets are available via Secret Service or KWallet-compatible paths. | Medium |
| **AWS Bedrock** | Add a Bedrock provider using AWS Signature Version 4 and region/model-aware connectivity checks, with estimated cost where direct spend data is unavailable. | Medium/High |
| **JetBrains AI** | Track local JetBrains AI activity from `~/.config/JetBrains/`. | Low |

## v5.3.0 — "Vanguard"

**Goal:** complete distribution work and cover the fast-growing AI coding tool surface using local filesystem-backed monitoring.

| Feature | Description | Technical Risk |
| ------- | ----------- | -------------- |
| **Flatpak package** | Finalize the existing Flatpak scaffold and add CI validation for manifest consistency, build, and test coverage. | Low |
| **Cursor** | Track local activity and self-managed limits from `~/.cursor/`. | Low |
| **Windsurf (Codeium)** | Track local activity and self-managed limits from `~/.codeium/`. | Low |
| **Shared local monitor base** | Consolidate install detection, recursive watching, debounce, and self-tracked usage increments for local subscription tools. | Low |

## v6.0.0 — "Nexus (Light)"

**Goal:** add practical team-adjacent integrations without building a custom backend.

| Feature | Description | Technical Risk |
| ------- | ----------- | -------------- |
| **Prometheus exporter** | Expose a local loopback-only `/metrics` endpoint for Grafana/Prometheus pipelines. | Medium |
| **Slack & Discord webhooks** | Send budget, quota, and connectivity alerts to incoming webhooks using the existing notification pipeline as the event source. | Low |
| **JSON/CSV auto-export** | Write timestamped JSON and CSV exports from local SQLite history to user-selected directories, including network-mounted paths. | Low |
| **Removal of PostgreSQL/team backend work** | Explicitly drop PostgreSQL, multi-user database, login, and web dashboard plans from the widget itself. | N/A |

## Explicit Non-Goals

- No PostgreSQL migration inside the plasmoid/plugin
- No multi-user or cross-machine aggregation service
- No standalone web dashboard owned by this repo
- No team login/account system
- No non-Linux browser sync abstraction until there is a platform target that can exercise it
